Utility for patching F-Zero Final

Run [F-Zero Final Patcher.exe], select F-Zero and Grand Prix 2 roms or paste their paths into the text boxes, click Patch.