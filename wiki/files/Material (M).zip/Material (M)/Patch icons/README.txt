This files are used to create an alternative way to change icons of some Emulators on Gmenu2x
After this proceed all emulator that uses icons named generically "icon.png" will change to a proper name.
So when you change the skin on settings all icons gonna change too.
 If do not change press 
(power+select) to reset skin.

Warning: this proceed will change folder and other settings of this emulators to default values.


Step (1) 

Copy the all contents in folder "emulators" to internal folder: media/home/.gmenu2x/sections/emulators
What it does?
Now the setup will claim for a specif icon on default skin or even in a custon skin.

Step (2) 
Copy the all contents in folder "default icons" to internal folder: media/home/.gmenu2x/skins/Default/icons
What it does?
Now when applied the settings (of previous step) the system gonna find a specif default icon avoiding the use of 
a generic icon.


Now All icons always gonna change when you setup a new skin. =)

